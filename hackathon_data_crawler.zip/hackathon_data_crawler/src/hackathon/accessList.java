package hackathon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class accessList {
	
	public static void main(String[] args)
	{
		JSONObject tmp;
	    try {
	    	Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.29.128:3306/hack?" +
			        "user=root&password=");

			PreparedStatement preparedStatement;
		
		for(int i=1;i<=131;i++) //37
		{
			String src = getUrlSource("https://api.data.umac.mo/service/facilities/access_control_records/v1.0.0/all?door_id=W12&access_date_from=2018-10-15T00%3A00%3A00&access_date_to=2018-10-15T12%3A53%3A01&count&page="+i);
			//String src=getUrlSource("https://www.deliver2u.mo/test_aomi.html");
			System.out.println(src);
			
			JSONObject obj = new JSONObject(src);

			JSONArray jsonOb = obj.getJSONArray("_embedded");

			System.out.println(jsonOb.getJSONObject(0).getString("hashID"));

			for(int y=0;y<100;y++){
				//System.out.println(tmp.get("ID").toString());
				preparedStatement = conn.prepareStatement("INSERT into checkinout VALUES(NULL,?,?,?,?,?)");
				preparedStatement.setString(1,jsonOb.getJSONObject(y).getString("_id").toString());
				preparedStatement.setString(2,jsonOb.getJSONObject(y).getString("hashID").toString());
				preparedStatement.setString(3,jsonOb.getJSONObject(y).getString("doorID").toString());
				preparedStatement.setString(4,jsonOb.getJSONObject(y).getString("accessDate").toString().replace("T", " ").substring(0,19));
				preparedStatement.setString(5, jsonOb.getJSONObject(y).getString("grantResult").toString() );
				
				preparedStatement.executeUpdate();
			}
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String getUrlSource(String url) {
		HttpsURLConnection yc;
		long timestamp = System.currentTimeMillis() / 1000;
        StringBuilder a = new StringBuilder();
		try {
			URL yahoo = new URL(url);
			yc = (HttpsURLConnection)yahoo.openConnection();
			//yc.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			//yc.addRequestProperty("channel", "3");
			yc.setRequestMethod("GET");
			yc.setRequestProperty("Authorization", "Bearer ");
			yc.setRequestProperty("Accept","application/json");

			
        BufferedReader in = new BufferedReader(new InputStreamReader(
                yc.getInputStream(), "UTF-8"));
        String inputLine;
        while ((inputLine = in.readLine()) != null)
            a.append(inputLine);
        in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			getUrlSource(url);
		}
        return a.toString();
    }

}
